// module.exports.firebase = require("./firebase");
module.exports.rbacAuth = require("./rbac.js");
